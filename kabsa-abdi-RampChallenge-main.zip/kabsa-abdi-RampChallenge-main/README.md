# Ramp iOS Challenges
Here is the smiley face created in challenge three!

<p align="center">
  <img width="300" height="300" src="smile.png">
</p>
